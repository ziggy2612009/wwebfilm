import React from 'react'

export default function page() {
  return (
    <div>
      <h1>
        Bahan bakar
      </h1>
      <h1>
        Roda
      </h1>
    </div>
  )
}
