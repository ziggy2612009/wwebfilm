import React from 'react'

export default function page() {
  return (
    <div>
      <h1>roda 2</h1>
      <h1>roda 4</h1>
      <h1>roda 6</h1>
    </div>
  )
}
