import React from 'react'

export default function page() {
  return (
    <div>
      <h1>listrik</h1>
      <h1>baterai</h1>
      <h1>bensisn</h1>
    </div>
  )
}
