import React from 'react'

export default function page() {
  return (
    <div>
      <h1>
        ini honda
      </h1>
    </div>
  )
}
