import React from "react";

export default function page() {
  return (
    <div>
      <h1 className="text-black">INI MEREK MOBIL</h1>
      <h1> mobil agya</h1>
      <h1> mobil honda</h1>
      <h1> mobil hyundai</h1>
      <h1> mobil toyota</h1>
    </div>
  );
}
